import logging
from pathlib import Path

from playwright.async_api import Browser, Page, TimeoutError as PlaywrightTimeoutError, async_playwright

from app.config import BASE_DIR, settings


logger = logging.getLogger(__name__)


DEFAULT_TIMEOUT_MS = 15000
DEFAULT_WAIT_AFTER_LOAD_MS = 5000
DEFAULT_WAIT_AFTER_SCROLL_MS = 2000
PRICE_WITH_SPP_SELECTOR = "span.tsHeadline600Large"
PRICE_WITHOUT_SPP_SELECTOR = "span.pdp_i4b.tsHeadline500Medium"
DEBUG_HTML_DIR = Path(BASE_DIR) / "app" / "data" / "debug"


class OzonPriceMonitor:
    """Асинхронный монитор витринных цен Ozon через Playwright."""

    def __init__(self, timeout_ms: int = DEFAULT_TIMEOUT_MS) -> None:
        self.timeout_ms = timeout_ms

    async def get_price(self, url: str) -> dict[str, float | None]:
        """Открыть карточку товара и вернуть цены с Ozon Банком и без него."""
        logger.info("Запуск мониторинга цены Ozon: url=%s", url)

        browser: Browser | None = None
        try:
            async with async_playwright() as playwright:
                headless_env_value = settings.PRICE_MONITOR_HEADLESS
                headless = str(headless_env_value).strip().lower() == "true"
                logger.info("PRICE_MONITOR_HEADLESS=%s", headless_env_value)
                logger.info("Playwright headless=%s", headless)

                browser = await playwright.chromium.launch(headless=headless)
                if headless:
                    logger.info("Playwright запущен в headless режиме")
                else:
                    logger.info("Playwright запущен в видимом режиме")
                context = await browser.new_context(
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                    viewport={"width": 1280, "height": 800},
                    locale="ru-RU",
                )
                page = await context.new_page()
                page.set_default_timeout(self.timeout_ms)
                logger.info("Stealth режим отключён")

                await self._open_product_page(page, url)

                price_with_spp_text = await self._get_price_text(page, PRICE_WITH_SPP_SELECTOR, url, "price_with_spp")
                price_without_spp_text = await self._get_price_text(
                    page,
                    PRICE_WITHOUT_SPP_SELECTOR,
                    url,
                    "price_without_spp",
                )

                if price_with_spp_text is None or price_without_spp_text is None:
                    fallback_with_spp, fallback_without_spp = await self._extract_fallback_prices(page, url)
                    price_with_spp_text = price_with_spp_text or fallback_with_spp
                    price_without_spp_text = price_without_spp_text or fallback_without_spp

                price_with_spp = self._clean_price(price_with_spp_text)
                price_without_spp = self._clean_price(price_without_spp_text)

                logger.info(
                    "Результат парсинга цен Ozon: url=%s, raw_with_spp=%s, raw_without_spp=%s, price_with_spp=%s, price_without_spp=%s",
                    url,
                    price_with_spp_text,
                    price_without_spp_text,
                    price_with_spp,
                    price_without_spp,
                )

                return {
                    "price_with_spp": price_with_spp,
                    "price_without_spp": price_without_spp,
                }
        except PlaywrightTimeoutError as exc:
            logger.exception("Таймаут при мониторинге цены Ozon: url=%s, error=%s", url, exc)
            raise RuntimeError(f"Не удалось дождаться загрузки страницы или цен для {url}") from exc
        except Exception as exc:
            logger.exception("Ошибка мониторинга цены Ozon: url=%s, error=%s", url, exc)
            raise RuntimeError(f"Не удалось получить цены с витрины Ozon для {url}") from exc
        finally:
            if browser is not None:
                await browser.close()

    async def _open_product_page(self, page: Page, url: str) -> None:
        """Открыть страницу товара и дождаться основной загрузки."""
        await page.goto(url, wait_until="domcontentloaded", timeout=self.timeout_ms)
        await page.wait_for_load_state("networkidle", timeout=self.timeout_ms)
        await page.wait_for_timeout(DEFAULT_WAIT_AFTER_LOAD_MS)
        await page.mouse.wheel(0, 3000)
        await page.wait_for_timeout(DEFAULT_WAIT_AFTER_SCROLL_MS)

    async def _get_price_text(self, page: Page, selector: str, url: str, label: str) -> str | None:
        """Получить сырой текст цены по селектору без ожидания visible."""
        try:
            locator = page.locator(selector)
            count = await locator.count()
            if count > 0:
                text = await locator.first.inner_text()
                logger.info("Цена найдена по основному селектору: url=%s, label=%s, selector=%s, text=%s", url, label, selector, text)
                return text

            html = await page.content()
            logger.warning(
                "Селектор цены не найден: url=%s, label=%s, selector=%s, html_length=%s",
                url,
                label,
                selector,
                len(html),
            )
            await self._dump_debug_html(html, label)
            return None
        except Exception as exc:
            html = await page.content()
            logger.warning(
                "Ошибка чтения цены по селектору: url=%s, label=%s, selector=%s, error=%s, html_length=%s",
                url,
                label,
                selector,
                exc,
                len(html),
            )
            await self._dump_debug_html(html, label)
            return None

    async def _extract_fallback_prices(self, page: Page, url: str) -> tuple[str | None, str | None]:
        """Fallback: найти любые цены в span и взять первую и вторую подходящие."""
        try:
            all_prices = await page.locator("span").all_inner_texts()
            html = await page.content()
            candidates = [text.strip() for text in all_prices if "₽" in text]
            price_with_spp = candidates[0] if len(candidates) > 0 else None
            price_without_spp = candidates[1] if len(candidates) > 1 else None

            logger.warning(
                "Сработал fallback-парсинг цен Ozon: url=%s, fallback_with_spp=%s, fallback_without_spp=%s, candidates=%s, html_length=%s",
                url,
                price_with_spp,
                price_without_spp,
                candidates[:10],
                len(html),
            )
            return price_with_spp, price_without_spp
        except Exception as exc:
            logger.warning("Fallback-парсинг цен не удался: url=%s, error=%s", url, exc)
            return None, None

    async def _dump_debug_html(self, html: str, label: str) -> None:
        """Сохранить HTML страницы в debug-файл для разбора проблемного кейса."""
        try:
            DEBUG_HTML_DIR.mkdir(parents=True, exist_ok=True)
            file_path = DEBUG_HTML_DIR / f"{label}_page_dump.html"
            file_path.write_text(html, encoding="utf-8")
            logger.warning("HTML страницы сохранён в debug-файл: path=%s", file_path)
        except Exception as exc:
            logger.warning("Не удалось сохранить HTML страницы в debug-файл: error=%s", exc)

    def _clean_price(self, raw_text: str | None) -> float | None:
        """Очистить текст цены и вернуть float."""
        if not raw_text:
            return None

        normalized = (
            raw_text.replace("₽", "")
            .replace("&thinsp;", "")
            .replace("\u2009", "")
            .replace("\xa0", " ")
            .replace(" ", "")
            .replace(",", ".")
            .strip()
        )

        if not normalized:
            return None

        try:
            return float(normalized)
        except ValueError:
            logger.warning("Не удалось преобразовать цену в float: raw_text=%s, normalized=%s", raw_text, normalized)
            return None
